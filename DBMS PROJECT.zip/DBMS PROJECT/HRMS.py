from flask import Flask, request, render_template, redirect, url_for, flash, session, send_file
import mysql.connector
from mysql.connector import Error
import matplotlib.pyplot as plt
import io
import random

app = Flask(__name__)
app.secret_key = 'your_secure_secret_key_here'  # Replace with a random string or os.urandom(24)

# Database configuration
db_config = {
    "host": "127.0.0.1",
    "user": "root",
    "password": "sunder@3003",
    "database": "dbms",
    "connection_timeout": 28800,
    "read_timeout": 28800
}

def get_db_connection():
    """Create and return a database connection."""
    try:
        db = mysql.connector.connect(**db_config)
        return db
    except Error as e:
        print(f"Error connecting to MySQL: {e}")
        return None

def get_table_name(department):
    """Return the appropriate table name based on department."""
    department = department.lower()
    if department == 'admin':
        return 'employees_admin'
    return f"employees_{department}"

# Session Management
@app.before_request
def clear_invalid_sessions():
    if not session.get('logged_in') and request.path not in ['/login', '/user_login', '/clear_session', '/admin/requests', '/chat_admin']:
        session.clear()

@app.route('/login', methods=['GET', 'POST'])
def login():
    print(f"Request method: {request.method}")
    if request.method == 'POST':
        print(f"Form data received: {request.form}")
        username = request.form.get('username')
        password = request.form.get('password')
        department = request.form.get('department')

        print(f"Attempting login with: {username}, {password}, {department}")
        if not all([username, password, department]):
            print("Missing form data.")
            flash("All fields are required.", "error")
            return render_template('login.html')

        db = get_db_connection()
        if db is None or not db.is_connected():
            flash("Unable to connect to the database.", "error")
            print("Database connection failed or lost.")
            return render_template('login.html')

        try:
            cursor = db.cursor(dictionary=True)
            print(f"Querying admins for {username}, {department}")
            cursor.execute("SELECT * FROM admins WHERE username = %s AND department = %s", (username, department))
            admin = cursor.fetchone()
            print(f"Found admin: {admin}")
            if admin and admin['password'] == password:
                print("Login successful!")
                session['logged_in'] = True
                session['is_admin'] = True
                session['department'] = department
                return redirect(url_for('index'))
            else:
                print("Login failed: Check username, password, or department.")
                flash('Invalid username or password', "error")
        except Error as e:
            print(f"Error: {e}")
            flash("An error occurred during login.", "error")
        finally:
            cursor.close()
            if db.is_connected():
                db.close()
    else:
        print("GET request received, showing login page.")

    return render_template('login.html')

@app.route('/user_login', methods=['GET', 'POST'])
def user_login():
    if session.get('logged_in'):
        return redirect(url_for('user_dashboard'))
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        if not all([username, password]):
            flash("All fields are required.", "error")
            return render_template('user_login.html')
        
        db = get_db_connection()
        if db is None or not db.is_connected():
            flash("Unable to connect to the database.", "error")
            print("Database connection failed or lost.")
            return render_template('user_login.html')

        try:
            print(f"Attempting login for username: {username}")
            cursor = db.cursor(dictionary=True)
            departments = ['hr', 'finance', 'it']
            user = None
            for dept in departments:
                table_name = f"employees_{dept}"
                print(f"Checking {table_name} for {username}")
                cursor.execute(f"SELECT EmployeeID, username, password, department FROM {table_name} WHERE username = %s AND password = %s", (username, password))
                user = cursor.fetchone()
                print(f"Found user: {user}")
                if user:
                    break
            if user:
                session['logged_in'] = True
                session['user_id'] = user['EmployeeID']
                session['department'] = user['department']
                return redirect(url_for('user_dashboard'))
            else:
                flash("Invalid username or password.", "error")
        except Error as e:
            print(f"Database error: {e}")
            flash("An error occurred during login.", "error")
        finally:
            if 'cursor' in locals():
                cursor.close()
            if db.is_connected():
                db.close()
    return render_template('user_login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        print(f"Form data received: {request.form}")
        username = request.form.get('username')
        first_name = request.form.get('first_name')
        last_name = request.form.get('last_name')
        password = request.form.get('password')
        email = request.form.get('email')
        phone_number = request.form.get('phone_number')
        job_id = request.form.get('job_id')
        job_title = request.form.get('job_title')
        department = request.form.get('department')

        print(f"Registering with: {username}, {first_name}, {last_name}, {email}, {phone_number}, {job_id}, {job_title}, {department}")
        if not all([username, first_name, last_name, password, email, phone_number, job_id, job_title, department]):
            print("Missing form data.")
            flash("All fields are required.", "error")
            return redirect(url_for('register'))

        db = get_db_connection()
        if db is None or not db.is_connected():
            flash("Unable to connect to the database.", "error")
            print("Database connection failed or lost.")
            return redirect(url_for('register'))

        try:
            cursor = db.cursor()
            cursor.execute("""
                INSERT INTO requests (username, first_name, last_name, email, phone_number, job_id, job_title, department, password, status)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, 'Pending')
            """, (username, first_name, last_name, email, phone_number, job_id, job_title, department, password))
            db.commit()
            flash("Registration request submitted successfully. Await admin approval.", "success")
        except Error as e:
            print(f"Error: {e}")
            flash("An error occurred while submitting the request.", "error")
        finally:
            cursor.close()
            if db.is_connected():
                db.close()

        return redirect(url_for('login'))
    return render_template('register.html')

@app.route('/clear_session')
def clear_session():
    session.clear()
    flash('Session cleared.', 'success')
    return redirect(url_for('login'))

@app.route('/')
def index():
    if not session.get('logged_in'):
        return redirect(url_for('login'))
    department = session.get('department')
    table_name = get_table_name(department)

    db = get_db_connection()
    if db is None or not db.is_connected():
        flash("Unable to connect to the database.", "error")
        return render_template('hrms.html', employees=[], tasks=[])

    try:
        cursor = db.cursor(dictionary=True)
        # Fetch employees
        cursor.execute(f"SELECT * FROM {table_name}")
        employees = cursor.fetchall()
        # Fetch tasks for the department
        cursor.execute("SELECT task_id, task_description, assigned_date, due_date, status, remarks, employee_id FROM tasks WHERE department = %s", (department,))
        tasks = cursor.fetchall()
        cursor.close()
        if db.is_connected():
            db.close()
        return render_template('hrms.html', employees=employees, tasks=tasks)
    except Error as e:
        print(f"Error fetching data: {e}")
        flash("An error occurred while fetching data.", "error")
        return render_template('hrms.html', employees=[], tasks=[])

@app.route('/add_employee', methods=['GET', 'POST'])
def add_employee():
    if not session.get('logged_in') or not session.get('is_admin'):
        return redirect(url_for('login'))
    
    department = session.get('department')
    table_name = get_table_name(department)

    if request.method == 'POST':
        first_name = request.form.get('first_name')
        last_name = request.form.get('last_name')
        email = request.form.get('email')
        phone_number = request.form.get('phone_number')
        hire_date = request.form.get('hire_date')
        job_id = request.form.get('job_id')
        job_title = request.form.get('job_title')
        salary = request.form.get('salary')
        username = request.form.get('username')
        password = request.form.get('password')
        
        try:
            db = get_db_connection()
            if db is None or not db.is_connected():
                flash("Unable to connect to the database.", "error")
                return redirect(url_for('add_employee'))
            cursor = db.cursor()
            cursor.execute(f"""
                INSERT INTO {table_name} (first_name, last_name, email, phone_number, hire_date, job_id, job_title, salary, username, password)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            """, (first_name, last_name, email, phone_number, hire_date, job_id, job_title, salary, username, password))
            db.commit()
            flash("Employee added successfully.", "success")
            cursor.close()
            if db.is_connected():
                db.close()
            return redirect(url_for('index'))
        except mysql.connector.Error as err:
            print(f"Error: {err}")
            flash("There was an error inserting the data into the database.", "error")
            return redirect(url_for('add_employee'))
    return render_template('add_employee.html')

@app.route('/edit_employee/<int:id>', methods=['GET', 'POST'])
def edit_employee(id):
    if not session.get('logged_in') or not session.get('is_admin'):
        return redirect(url_for('login'))
    
    department = session.get('department')
    table_name = get_table_name(department)

    db = get_db_connection()
    if db is None or not db.is_connected():
        flash("Unable to connect to the database.", "error")
        return redirect(url_for('index'))

    try:
        cursor = db.cursor(dictionary=True)
        cursor.execute(f"SELECT * FROM {table_name} WHERE EmployeeID = %s", (id,))
        employee = cursor.fetchone()

        if not employee:
            flash("Employee not found.", "error")
            return redirect(url_for('index'))

        if request.method == 'POST':
            new_salary = request.form.get('salary')
            new_job_id = request.form.get('job_id')
            if not new_salary or not new_salary.isdigit():
                flash("Please enter a valid salary amount.", "error")
            elif not new_job_id or not new_job_id.isdigit():
                flash("Please enter a valid job ID (numeric value).", "error")
            else:
                cursor.execute(f"UPDATE {table_name} SET salary = %s, job_id = %s WHERE EmployeeID = %s", (int(new_salary), int(new_job_id), id))
                db.commit()
                flash("Employee details updated successfully.", "success")
                return redirect(url_for('index'))

        return render_template('edit_employee.html', employee=employee)

    except Error as e:
        print(f"Error: {e}")
        flash("An error occurred while editing the employee.", "error")
    finally:
        cursor.close()
        if db.is_connected():
            db.close()

    return redirect(url_for('index'))

@app.route('/delete_employee/<int:id>', methods=['POST'])
def delete_employee(id):
    if not session.get('logged_in') or not session.get('is_admin'):
        return redirect(url_for('login'))
    department = session.get('department')
    table_name = get_table_name(department)
    
    try:
        db = get_db_connection()
        if db is None or not db.is_connected():
            flash("Unable to connect to the database.", "error")
            return redirect(url_for('index'))
        cursor = db.cursor()
        cursor.execute(f"DELETE FROM {table_name} WHERE EmployeeID = %s", (id,))
        db.commit()
        cursor.close()
        if db.is_connected():
            db.close()
        flash("Employee deleted successfully.", "success")
    except mysql.connector.Error as err:
        print(f"Error: {err}")
        flash("There was an error deleting the employee.", "error")
    return redirect(url_for('index'))

@app.route('/employee_performance/<int:id>')
def employee_performance(id):
    tasks = random.randint(50, 100)
    time = random.randint(20, 40)
    leaves = random.randint(5, 10)
    updates = random.randint(10, 20)

    labels = ['Tasks', 'Time', 'Leaves', 'Updates']
    values = [tasks, time, leaves, updates]

    fig, ax = plt.subplots()
    ax.pie(values, labels=labels, autopct='%1.1f%%', startangle=90)
    ax.axis('equal')  

    img = io.BytesIO()
    plt.savefig(img, format='png')
    img.seek(0)
    plt.close()
    return send_file(img, mimetype='image/png')

@app.route('/admin/requests', methods=['GET', 'POST'])
def admin_requests():
    if not session.get('logged_in') or not session.get('is_admin'):
        return redirect(url_for('login'))
    department = session.get('department')
    table_name = get_table_name(department)

    db = get_db_connection()
    if db is None or not db.is_connected():
        flash("Unable to connect to the database.", "error")
        return redirect(url_for('login'))

    try:
        cursor = db.cursor(dictionary=True)
        requests = []
        if request.method == 'POST':
            request_id = request.form.get('request_id')
            action = request.form.get('action')
            print(f"Processing action: {action} for request_id: {request_id}")
            if action == 'approve':
                cursor.execute("SELECT username, first_name, last_name, email, phone_number, job_id, job_title, department, password FROM requests WHERE id = %s", (request_id,))
                req = cursor.fetchone()
                print(f"Fetched request: {req}")
                if req and req['department'] == department:
                    try:
                        cursor.execute(f"""
                            INSERT INTO {table_name} (username, first_name, last_name, email, phone_number, hire_date, job_id, job_title, salary, password)
                            VALUES (%s, %s, %s, %s, %s, CURDATE(), %s, %s, %s, %s)
                        """, (req['username'], req['first_name'], req['last_name'], req['email'], req['phone_number'], req['job_id'], req['job_title'], 0, req['password']))
                        cursor.execute("UPDATE requests SET status = 'Approved' WHERE id = %s", (request_id,))
                        db.commit()
                        print("Commit successful")
                        flash("Employee approved and added successfully.", "success")
                    except mysql.connector.Error as e:
                        print(f"Insert error: {e}")
                        flash("Failed to add employee to database.", "error")
                    finally:
                        return redirect(url_for('index'))
                else:
                    print("No matching request or department mismatch")
                    flash("Invalid request or department mismatch.", "error")
                    return redirect(url_for('index'))
            elif action == 'reject':
                cursor.execute("UPDATE requests SET status = 'Rejected' WHERE id = %s", (request_id,))
                db.commit()
                print("Reject action committed")
                flash("Request rejected successfully.", "success")
                return redirect(url_for('index'))

        cursor.execute("""
            SELECT id, username, department, status
            FROM requests
            WHERE department = %s AND status = 'Pending'
        """, (department,))
        requests = cursor.fetchall()
        if not requests:
            return redirect(url_for('index'))

    except Error as e:
        print(f"Error: {e}")
        flash("An error occurred while fetching requests.", "error")
        requests = []
    finally:
        cursor.close()
        if db.is_connected():
            db.close()

    return render_template('admin_requests.html', requests=requests)

@app.route('/user_dashboard')
def user_dashboard():
    if not session.get('logged_in') or session.get('is_admin'):
        return redirect(url_for('user_login'))
    user_id = session.get('user_id')
    department = session.get('department')
    table_name = get_table_name(department)

    db = get_db_connection()
    if db is None or not db.is_connected():
        flash("Unable to connect to the database.", "error")
        return render_template('user_dashboard.html', tasks=[])

    try:
        cursor = db.cursor(dictionary=True)
        cursor.execute("SELECT task_id, task_description, assigned_date, due_date, status, remarks FROM tasks WHERE employee_id = %s AND department = %s", (user_id, department))
        tasks = cursor.fetchall()
        cursor.close()
        if db.is_connected():
            db.close()
        return render_template('user_dashboard.html', tasks=tasks)
    except Error as e:
        print(f"Error: {e}")
        flash("An error occurred while fetching tasks.", "error")
    finally:
        if 'cursor' in locals():
            cursor.close()
        if db.is_connected():
            db.close()

    return render_template('user_dashboard.html', tasks=[])

@app.route('/complete_task/<int:task_id>', methods=['POST'])
def complete_task(task_id):
    if not session.get('logged_in') or session.get('is_admin'):
        return redirect(url_for('user_login'))
    user_id = session.get('user_id')
    department = session.get('department')

    db = get_db_connection()
    if db is None or not db.is_connected():
        flash("Unable to connect to the database.", "error")
        return redirect(url_for('user_dashboard'))

    try:
        cursor = db.cursor()
        cursor.execute("SELECT employee_id, department FROM tasks WHERE task_id = %s", (task_id,))
        task = cursor.fetchone()
        if task and task[0] == user_id and task[1] == department:
            cursor.execute("UPDATE tasks SET status = 'Completed' WHERE task_id = %s", (task_id,))
            db.commit()
            flash("Task marked as completed. Awaiting admin review.", "success")  # Notification for user
        else:
            flash("Invalid task or unauthorized action.", "error")
    except Error as e:
        print(f"Error: {e}")
        flash("An error occurred while updating the task.", "error")
    finally:
        cursor.close()
        if db.is_connected():
            db.close()

    return redirect(url_for('user_dashboard'))

@app.route('/assign_task/<int:employee_id>', methods=['GET', 'POST'])
def assign_task(employee_id):
    if not session.get('logged_in') or not session.get('is_admin'):
        return redirect(url_for('login'))
    department = session.get('department')
    table_name = get_table_name(department)

    db = get_db_connection()
    if db is None or not db.is_connected():
        flash("Unable to connect to the database.", "error")
        return redirect(url_for('index'))

    if request.method == 'POST':
        task_description = request.form.get('task_description')
        due_date = request.form.get('due_date')
        if task_description and due_date:
            try:
                cursor = db.cursor()
                cursor.execute("INSERT INTO tasks (employee_id, department, task_description, assigned_date, due_date, status) VALUES (%s, %s, %s, CURDATE(), %s, 'Pending')", 
                              (employee_id, department, task_description, due_date))
                db.commit()
                flash("Task assigned successfully.", "success")
            except Error as e:
                print(f"Error: {e}")
                flash("An error occurred while assigning the task.", "error")
            finally:
                cursor.close()
                if db.is_connected():
                    db.close()
            return redirect(url_for('index'))

    try:
        cursor = db.cursor(dictionary=True)
        cursor.execute(f"SELECT EmployeeID, first_name, last_name FROM {table_name} WHERE EmployeeID = %s", (employee_id,))
        employee = cursor.fetchone()
        cursor.close()
        if db.is_connected():
            db.close()
        return render_template('assign_task.html', employee=employee)
    except Error as e:
        print(f"Error: {e}")
        flash("An error occurred while fetching employee.", "error")
    finally:
        if 'cursor' in locals():
            cursor.close()
        if db.is_connected():
            db.close()

    return redirect(url_for('index'))

@app.route('/review_task/<int:task_id>', methods=['GET', 'POST'])
def review_task(task_id):
    if not session.get('logged_in') or not session.get('is_admin'):
        return redirect(url_for('login'))
    department = session.get('department')

    db = get_db_connection()
    if db is None or not db.is_connected():
        flash("Unable to connect to the database.", "error")
        return redirect(url_for('index'))

    try:
        cursor = db.cursor(dictionary=True)
        if request.method == 'POST':
            action = request.form.get('action')
            remarks = request.form.get('remarks')
            if action == 'reassign':
                cursor.execute("UPDATE tasks SET status = 'Reassigned', remarks = %s WHERE task_id = %s", (remarks, task_id))
            elif action == 'done':
                cursor.execute("UPDATE tasks SET status = 'Done', remarks = %s WHERE task_id = %s", (remarks, task_id))
            db.commit()
            flash("Task reviewed successfully.", "success")
            return redirect(url_for('index'))
        else:
            cursor.execute("SELECT * FROM tasks WHERE task_id = %s AND department = %s", (task_id, department))
            task = cursor.fetchone()
            if not task:
                flash("Task not found or unauthorized access.", "error")
                return redirect(url_for('index'))
            return render_template('review_task.html', task=task)

    except Error as e:
        print(f"Error: {e}")
        flash("An error occurred while reviewing the task.", "error")
    finally:
        if 'cursor' in locals():
            cursor.close()
        if db.is_connected():
            db.close()

    return redirect(url_for('index'))

@app.route('/chat_admin', methods=['GET'])
def chat_admin():
    if not session.get('logged_in') or not session.get('is_admin'):
        return redirect(url_for('login'))
    return render_template('chat_admin.html')

if __name__ == '__main__':
    app.run(debug=True)