from flask import Flask, request, render_template, redirect, url_for, flash, session, send_file
import mysql.connector
from mysql.connector import Error
import matplotlib.pyplot as plt
import io
import random

app = Flask(__name__)
app.secret_key = 'your_secret_key'  # Required for flashing messages

# Database configuration
db_config = {
    "host": "127.0.0.1",
    "user": "root",
    "password": "sunder@3003",
    "database": "dbms",
    "connection_timeout": 28800,
    "read_timeout": 28800
}

def get_db_connection():
    """Create and return a database connection."""
    try:
        db = mysql.connector.connect(**db_config)
        return db
    except Error as e:
        print(f"Error connecting to MySQL: {e}")
        return None

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        if username == 'admin' and password == 'HRMS':
            session['logged_in'] = True
            return redirect(url_for('index'))
        else:
            flash('Invalid username or password', 'error')

    return render_template('login.html')

@app.route('/logout')
def logout():
    session.pop('logged_in', None)
    flash('You have been logged out.', 'success')
    return redirect(url_for('login'))

@app.route('/clear_session')
def clear_session():
    session.clear()
    flash('Session cleared.', 'success')
    return redirect(url_for('login'))

@app.route('/')
def index():
    if not session.get('logged_in'):
        return redirect(url_for('login'))
    
    db = get_db_connection()
    if db is None:
        flash("Unable to connect to the database.", "error")
        return render_template('hrms.html', employees=[])
    try:
        cursor = db.cursor(dictionary=True)
        cursor.execute("SELECT * FROM employees")
        employees = cursor.fetchall()
        cursor.close()
        db.close()
        # Debugging: Print fetched data
        print("Fetched Employees Data:")
        for employee in employees:
            print(employee)
        return render_template('hrms.html', employees=employees)
    except Error as e:
        print(f"Error fetching employees: {e}")
        flash("An error occurred while fetching employee data.", "error")
        return render_template('hrms.html', employees=[])

@app.route('/add_employee', methods=['GET', 'POST'])
def add_employee():
    if not session.get('logged_in'):
        return redirect(url_for('login'))
    
    if request.method == 'POST':
        first_name = request.form['first_name']
        last_name = request.form['last_name']
        email = request.form['email']
        phone_number = request.form['phone_number']
        hire_date = request.form['hire_date']
        job_id = request.form['job_id']
        job_title = request.form['job_title']
        salary = request.form['salary']
        
        # Debugging: Print form data
        print("Form Data Received:")
        print(f"First Name: {first_name}")
        print(f"Last Name: {last_name}")
        print(f"Email: {email}")
        print(f"Phone Number: {phone_number}")
        print(f"Hire Date: {hire_date}")
        print(f"Job ID: {job_id}")
        print(f"Job Title: {job_title}")
        print(f"Salary: {salary}")
        
        try:
            db = get_db_connection()
            if db is None:
                flash("Unable to connect to the database.", "error")
                return redirect(url_for('add_employee'))
            cursor = db.cursor()
            cursor.execute("""
                INSERT INTO employees (first_name, last_name, email, phone_number, hire_date, job_id, job_title, salary)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
            """, (first_name, last_name, email, phone_number, hire_date, job_id, job_title, salary))
            db.commit()
            print("Employee added successfully")
            cursor.close()
            db.close()
            return redirect(url_for('index'))
        except mysql.connector.Error as err:
            print(f"Error: {err}")
            flash("There was an error inserting the data into the database.", "error")
            return redirect(url_for('add_employee'))
    return render_template('add_employee.html')

@app.route('/delete_employee/<int:id>', methods=['POST'])
def delete_employee(id):
    if not session.get('logged_in'):
        return redirect(url_for('login')) 
    try:
        db = get_db_connection()
        if db is None:
            flash("Unable to connect to the database.", "error")
            return redirect(url_for('index'))
        cursor = db.cursor()
        cursor.execute("DELETE FROM employees WHERE EmployeeID = %s", (id,))
        db.commit()
        cursor.close()
        db.close()
        flash("Employee deleted successfully.", "success")
    except mysql.connector.Error as err:
        print(f"Error: {err}")
        flash("There was an error deleting the employee.", "error")
    return redirect(url_for('index'))

@app.route('/employee_performance/<int:id>')
def employee_performance(id):
    tasks = random.randint(50, 100)
    time = random.randint(20, 40)
    leaves = random.randint(5, 10)
    updates = random.randint(10, 20)

    labels = ['Tasks', 'Time', 'Leaves', 'Updates']
    values = [tasks, time, leaves, updates]

    fig, ax = plt.subplots()
    ax.pie(values, labels=labels, autopct='%1.1f%%', startangle=90)
    ax.axis('equal')  

    img = io.BytesIO()
    plt.savefig(img, format='png')
    img.seek(0)
    return send_file(img, mimetype='image/png')

if __name__ == '__main__':
    app.run(debug=True)